export { default } from '../../src/app/about/page';
